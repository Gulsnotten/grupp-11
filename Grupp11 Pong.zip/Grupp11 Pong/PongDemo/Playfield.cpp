/*
Team 11
Alexander Granell & Erik S�ll
10/6/2016
*/

#include "Playfield.h"
#include "SDL.h"


Playfield::Playfield()
{
}


Playfield::~Playfield()
{
}