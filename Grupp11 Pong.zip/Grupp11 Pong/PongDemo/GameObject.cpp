/*
Team 11
Alexander Granell & Erik S�ll
10/6/2016
*/

#include "GameObject.h"



GameObject::GameObject()
{
}


GameObject::~GameObject()
{
}

SDL_Rect GameObject::GetRect() const {
	return rect;
}

void GameObject::update() {

}