/*
Team 11
Alexander Granell & Erik S�ll
10/6/2016
*/

#pragma once
#include "Paddle.h"

class Playfield
{
public:
	Playfield();
	~Playfield();

	static const int WIDTH = 640;
	static const int HEIGHT = 360;
	static const int MARGIN = 8;
};

