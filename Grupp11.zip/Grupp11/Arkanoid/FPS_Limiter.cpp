/*
Team 11
Alexander Granell & Erik S�ll
10/6/2016
*/

#include "FPS_Limiter.h"



FPS_Limiter::FPS_Limiter()
{
	_lastTick = 0;
}


FPS_Limiter::~FPS_Limiter()
{
}

void FPS_Limiter::Delay(int fps) {
	int target = Config::SAMPLE_INTERVAL / fps;

	int wait = target - (SDL_GetTicks() - _lastTick);

	if (wait > 0) {
		SDL_Delay(wait);
	}

	_lastTick = SDL_GetTicks();
}